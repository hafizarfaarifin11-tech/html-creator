# HTML Maker v1.1.0

HTML Maker adalah aplikasi Android pembuat halaman website sederhana melalui editor visual. Aplikasi berjalan secara lokal menggunakan WebView dan tidak memerlukan akun atau backend.

## Fitur

- Editor visual dengan pratinjau kanvas langsung.
- Elemen: judul, teks, tombol, gambar, daftar bullet/nomor, kartu, kutipan, label, video YouTube, garis, dan jarak.
- Atur warna, font, ukuran, alignment, radius, dan latar halaman.
- Latar warna solid atau gradien.
- Upload gambar dari perangkat (PNG, JPG, WEBP, GIF; maksimal 1,2 MB per gambar) atau gunakan URL gambar HTTPS.
- Undo dan redo.
- Duplikasi, hapus, dan pindahkan elemen.
- Pratinjau ukuran Desktop, Tablet, dan Mobile.
- Template Landing Page, Portfolio, Link Bio, dan Katalog.
- Metadata SEO: judul, deskripsi, kata kunci, dan favicon.
- CSS tambahan untuk pengguna tingkat lanjut.
- Autosave lokal, ekspor HTML, ekspor proyek JSON, dan impor proyek JSON.

## Build dengan GitHub Actions

1. Upload seluruh isi ZIP ke repository, atau upload ZIP proyek ke root repository.
2. Pastikan workflow tersedia di `.github/workflows/android.yml`.
3. Commit ke branch `main` atau `master`, atau jalankan workflow secara manual dari tab Actions.
4. Setelah workflow sukses, unduh artifact `HTML-Maker-debug-APK`.
5. Ekstrak artifact dan instal `app-debug.apk`.

Workflow menggunakan Java 17, Android SDK Platform 35, Build Tools 35.0.0, dan Gradle 8.9. Build CI menggunakan perintah Gradle yang disiapkan runner sehingga tidak bergantung pada `gradlew`.

## Struktur penting

- `app/src/main/assets/index.html` — editor dan generator HTML.
- `app/src/main/java/com/webcraft/htmlmaker/MainActivity.java` — jembatan Android untuk ekspor file dan pemilih berkas.
- `.github/workflows/android.yml` — workflow GitHub Actions.

## Catatan

- File HTML yang diekspor bisa dibuka di browser modern.
- Video YouTube dan gambar dari URL memerlukan koneksi internet saat halaman hasil dibuka.
- Gambar lokal yang diunggah disematkan ke dalam HTML sebagai data URI, sehingga file HTML dapat menjadi lebih besar.
- Proyek dan autosave disimpan di penyimpanan lokal aplikasi. Ekspor JSON untuk membuat cadangan atau memindahkan proyek.
