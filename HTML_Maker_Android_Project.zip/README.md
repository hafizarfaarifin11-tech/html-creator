# HTML Maker — Android Project (SDK CI Fix)

Aplikasi Android pembuat halaman HTML melalui editor visual lokal.

## Build APK melalui GitHub Actions

1. Buat repository GitHub baru.
2. Unggah file `HTML_Maker_Android_Project.zip` ke root repository. Alternatifnya, ekstrak ZIP lalu unggah seluruh isinya.
3. Pastikan workflow aktif di `.github/workflows/android.yml`. Gunakan file workflow dari ZIP ini atau file `HTML_Maker_Android_CI_SDK_FIX.yml`.
4. Hapus/nonaktifkan workflow Android CI Java lama agar tidak menjalankan dua pipeline berbeda.
5. Commit perubahan, buka tab Actions, lalu jalankan `Build HTML Maker APK`.
6. Setelah selesai hijau, unduh artifact `HTML-Maker-debug-APK`.

## Versi toolchain

- JDK: 17
- Gradle: 8.9 (disiapkan oleh `gradle/actions/setup-gradle`)
- Android compile SDK: 35
- Android Build Tools: 35.0.0
- minSdk: 23
- targetSdk: 34

Workflow memakai `android-actions/setup-android@v4.0.4` untuk menyiapkan Android SDK, menerima lisensi, dan memasang paket SDK yang dibutuhkan. Workflow tidak memanggil `sdkmanager` untuk instalasi manual setelah setup action.

Workflow juga memakai Gradle yang disiapkan langsung oleh GitHub Actions, jadi build CI tidak bergantung pada file `gradlew` atau `gradle-wrapper.jar`.

## Kompatibilitas perangkat

Android 16 tidak mengharuskan compile SDK 36 untuk memasang aplikasi ini. Perangkat Android 16 tetap dapat menjalankan aplikasi dengan minSdk 23 dan targetSdk 34, selama tidak ada masalah kompatibilitas runtime khusus.

## Fitur

- Menambah judul, teks, tombol, gambar dari URL HTTPS, garis, dan jarak.
- Mengubah warna, ukuran teks, font, latar, posisi, bold, dan italic.
- Mengatur judul dokumen, warna halaman, font, dan lebar halaman.
- Memilih elemen, mengubah urutan, dan menghapus elemen.
- Pratinjau halaman.
- Ekspor HTML mandiri melalui pemilih lokasi penyimpanan Android.
- Impor/ekspor proyek JSON dan penyimpanan otomatis lokal.
