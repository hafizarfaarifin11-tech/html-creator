# HTML Maker — Android Project (Rebuilt)

Aplikasi Android untuk membuat halaman HTML melalui editor visual lokal.

## Isi paket

- `settings.gradle` dan `build.gradle` di root proyek.
- `app/` berisi source Android, WebView editor, dan resource.
- `gradlew` dan `gradlew.bat` sebagai launcher Gradle 8.9.
- `.github/workflows/android.yml` untuk membangun APK melalui GitHub Actions.

## Fitur aplikasi

- Menambahkan blok judul, teks, tombol, gambar dari URL HTTPS, garis, dan jarak.
- Mengedit teks, ukuran, warna, latar, posisi, tebal, dan miring.
- Mengatur judul dokumen, warna halaman, font, dan lebar halaman.
- Memilih elemen, menggeser urutan, dan menghapus elemen.
- Pratinjau halaman.
- Ekspor HTML mandiri melalui pemilih lokasi penyimpanan Android.
- Impor dan ekspor proyek JSON serta penyimpanan otomatis lokal.

## Cara paling mudah: unggah ZIP

1. Buat repository GitHub.
2. Unggah file `HTML_Maker_Android_Project.zip` ke root repository.
3. Ganti workflow bawaan (misalnya Android CI Java) dengan isi file `.github/workflows/android.yml` dari paket ini. Simpan di path persis `.github/workflows/android.yml`.
4. Commit perubahan, lalu buka tab **Actions**. Workflow ini akan mengekstrak ZIP, menemukan `settings.gradle`, dan membangun APK.
5. Unduh artifact `HTML-Maker-debug-APK` setelah workflow selesai hijau.

## Alternatif: unggah semua isi proyek

Ekstrak ZIP, lalu unggah seluruh isi di dalam folder proyek ke root repository. Jangan unggah folder luarnya saja sebagai satu folder bersarang. Pastikan `settings.gradle` dan `app/` terlihat di halaman utama repository.

## Catatan

- Java yang digunakan: 17.
- Gradle: 8.9.
- Android compile SDK: 35; target SDK: 34; minimum SDK: 23.
- Gambar pada versi ini menggunakan URL HTTPS.
- Build APK di GitHub membutuhkan koneksi internet karena runner mengunduh Gradle dan dependensi Android.
- Build lokal: jalankan `./gradlew assembleDebug` (Linux/macOS) atau `gradlew.bat assembleDebug` (Windows).
