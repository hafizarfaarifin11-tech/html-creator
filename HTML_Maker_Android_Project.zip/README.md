# HTML Maker v1.2.3

HTML Maker adalah aplikasi Android pembuat halaman website melalui editor visual. Aplikasi berjalan secara lokal menggunakan WebView dan tidak memerlukan akun atau backend.

## Fitur editor

- Editor visual dengan pratinjau kanvas langsung.
- Elemen: judul, teks, tombol, gambar, daftar bullet/nomor, kartu, kutipan, label, video YouTube, garis, dan jarak.
- Atur warna, font, ukuran, alignment, radius, dan latar halaman website.
- Latar website warna solid atau gradien.
- Upload gambar dari perangkat atau gunakan URL gambar HTTPS.
- Undo dan redo, duplikasi, hapus, dan pindahkan elemen.
- Pratinjau ukuran Desktop, Tablet, dan Mobile.
- Template Landing Page, Portfolio, Link Bio, dan Katalog.
- Metadata SEO: judul, deskripsi, kata kunci, dan favicon.
- CSS global halaman di tab Desain untuk aturan yang berlaku pada seluruh website.
- **CSS khusus per elemen:** setiap elemen mempunyai kolom CSS sendiri. Kode untuk satu teks tidak menimpa CSS teks lainnya.
- **Animasi @keyframes tiap elemen diisolasi otomatis**, termasuk saat beberapa elemen memakai nama keyframe yang sama.
- Selector per elemen diisolasi dengan atribut internal sehingga hanya elemen yang dipilih yang terkena gaya.
- Class CSS opsional untuk memberi nama seperti `melayang`, lalu gunakan `.melayang { ... }` pada kolom CSS elemen itu.
- CSS per elemen ikut tersimpan pada proyek JSON, tampil di preview, dan disertakan ke HTML ekspor.
- Ekspor HTML, ekspor proyek JSON, dan impor proyek JSON.

## Menu aplikasi

- Tombol tiga titik membuka menu Proyek, Tampilan, dan Informasi.
- Proyek baru tidak menimpa proyek yang sedang dibuka; proyek lama tetap ada di daftar.
- Tema aplikasi: Terang, Gelap, Midnight, Mint, Lavender, dan Cream.
- Tab Informasi menampilkan profil pembuat tetap (Fizz).

## Ikon aplikasi

- Ikon launcher adaptive untuk Android 8.0 ke atas, termasuk Android 16.
- Ikon launcher legacy untuk versi Android yang lebih lama.

## Build dengan GitHub Actions

Pertahankan workflow yang sudah digunakan sebelumnya di `.github/workflows/android.yml`. Untuk update ini, cukup timpa source project dengan isi ZIP dan jangan mengubah workflow. Build tetap memakai Java 17, Android SDK Platform 35, Build Tools 35.0.0, dan Gradle 8.9.

## Catatan

- Proyek disimpan secara lokal di perangkat. Gunakan ekspor JSON sebagai cadangan.
- CSS global ada di tab Desain. CSS khusus elemen ada pada pengaturan elemen yang dipilih.
- File HTML ekspor bisa dibuka di browser modern.
