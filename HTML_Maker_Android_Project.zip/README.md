# HTML Maker v1.2.2

HTML Maker adalah aplikasi Android pembuat halaman website melalui editor visual. Aplikasi berjalan secara lokal menggunakan WebView dan tidak memerlukan akun atau backend.

## Fitur editor

- Editor visual dengan pratinjau kanvas langsung.
- Elemen: judul, teks, tombol, gambar, daftar bullet/nomor, kartu, kutipan, label, video YouTube, garis, dan jarak.
- Atur warna, font, ukuran, alignment, radius, dan latar halaman website.
- Latar website warna solid atau gradien.
- Upload gambar dari perangkat (PNG, JPG, WEBP, GIF; maksimal 1,2 MB per gambar) atau gunakan URL gambar HTTPS.
- Undo dan redo.
- Duplikasi, hapus, dan pindahkan elemen.
- Pratinjau ukuran Desktop, Tablet, dan Mobile.
- Template Landing Page, Portfolio, Link Bio, dan Katalog.
- Metadata SEO: judul, deskripsi, kata kunci, dan favicon.
- CSS tambahan diterapkan langsung pada pratinjau kanvas dan HTML hasil ekspor; selector `body` otomatis diarahkan ke halaman website di kanvas.
- Setiap elemen memiliki kolom Nama Class CSS. Isi class, misalnya `melayang`, lalu targetkan hanya elemen itu dengan selector `.melayang` di CSS tambahan. Class ikut tersimpan di proyek JSON dan HTML ekspor.
- Ekspor HTML, ekspor proyek JSON, dan impor proyek JSON.

## Menu aplikasi

- Tombol tiga titik di kiri atas membuka menu Proyek, Tampilan, dan Informasi.
- Proyek baru tidak menimpa proyek yang sedang dibuka; proyek lama tetap ada di daftar dan dapat dibuka kembali.
- Proyek dapat diganti nama atau dihapus dari daftar.
- Penyimpanan daftar proyek menggunakan file internal aplikasi Android; tidak membutuhkan izin penyimpanan luas.
- Pilihan tema aplikasi: Terang, Gelap, Midnight, Mint, Lavender, dan Cream. Tema ini hanya mengubah tampilan editor, bukan website yang sedang dibuat.
- Tab Informasi menampilkan profil pembuat tetap (Fizz), versi aplikasi, platform, dan informasi fitur. Semua informasi bersifat statis dan tidak bisa diedit dari aplikasi.

## Ikon aplikasi

- Ikon launcher adaptive untuk Android 8.0 ke atas, termasuk Android 16.
- Ikon launcher legacy untuk versi Android yang lebih lama.
- Artwork vektor sumber tersedia di `branding/html_maker_icon.svg`.

## Build dengan GitHub Actions

1. Upload seluruh isi ZIP ke repository, atau upload ZIP proyek ke root repository.
2. Pertahankan workflow yang sudah digunakan sebelumnya di `.github/workflows/android.yml`.
3. Commit ke branch `main` atau `master`, atau jalankan workflow secara manual dari tab Actions.
4. Setelah workflow sukses, unduh artifact `HTML-Maker-debug-APK`.
5. Ekstrak artifact dan instal `app-debug.apk`.

Workflow tetap menggunakan Java 17, Android SDK Platform 35, Build Tools 35.0.0, dan Gradle 8.9. File workflow tidak diubah pada versi ini.

## Struktur penting

- `app/src/main/assets/index.html` — editor dan generator HTML.
- `app/src/main/java/com/webcraft/htmlmaker/MainActivity.java` — jembatan Android untuk penyimpanan proyek, ekspor file, dan pemilih berkas.
- `.github/workflows/android.yml` — workflow GitHub Actions.

## Catatan

- Proyek tersimpan di ruang penyimpanan internal aplikasi pada perangkat ini. Menghapus data aplikasi atau menghapus instalasi aplikasi dapat menghapus proyek; gunakan ekspor JSON untuk cadangan.
- File HTML yang diekspor bisa dibuka di browser modern.
- Video YouTube dan gambar dari URL memerlukan koneksi internet saat halaman hasil dibuka.
- Gambar lokal yang diunggah disematkan ke dalam HTML sebagai data URI, sehingga file HTML dapat menjadi lebih besar.
