# HTML Maker v1.2.1

## Perbaikan
- CSS tambahan sekarang diterapkan pada pratinjau kanvas secara langsung, bukan hanya saat HTML diekspor.
- Selector `body`, `html`, dan `:root` diarahkan ke area website pada kanvas agar CSS tidak mengubah tampilan antarmuka HTML Maker.
- Aturan `@keyframes`, `@media`, dan `@supports` tetap didukung pada pratinjau.
- HTML hasil ekspor tetap menyertakan CSS kustom asli.
- Tab Informasi sekarang statis: pembuat ditampilkan sebagai Fizz dan tidak ada kolom yang dapat diedit pengguna.
- Version Name diperbarui menjadi 1.2.1 (Version Code 5).

## Build
Workflow GitHub Actions tidak diubah. Tetap gunakan workflow yang sudah dipakai pada versi 1.2.0.
