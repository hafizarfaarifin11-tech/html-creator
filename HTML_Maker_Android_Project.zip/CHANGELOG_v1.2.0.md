# HTML Maker v1.2.0

- Mengganti emblem H. di kiri atas dengan tombol menu tiga titik.
- Menambahkan tab Proyek, Tampilan, dan Informasi.
- Menambahkan enam tema tampilan aplikasi: Terang, Gelap, Midnight, Mint, Lavender, dan Cream.
- Menambahkan daftar proyek yang menyimpan proyek lama saat proyek baru dibuat.
- Menambahkan buka kembali, ganti nama, dan hapus proyek.
- Memindahkan penyimpanan daftar proyek ke file internal aplikasi Android agar tidak bergantung pada IndexedDB di WebView lokal.
- Menambahkan profil pembuat yang bisa diedit pada tab Informasi.
- Memperbarui versi menjadi 1.2.0 (versionCode 4).
- Workflow SDK FIX v4 dipertahankan tanpa perubahan.
