package com.webcraft.htmlmaker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_FILE = 4101;
    private static final int REQUEST_IMPORT_FILE = 4102;
    private static final int MAX_EXPORT_BYTES = 8 * 1024 * 1024;
    private static final int MAX_PROJECT_LIBRARY_BYTES = 48 * 1024 * 1024;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private byte[] pendingBytes;
    private String pendingMime;
    private String pendingName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(0xFFF5F6F8);
        window.setNavigationBarColor(0xFFF5F6F8);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF5F6F8);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("Lanjutkan", (dialog, which) -> result.confirm())
                        .setNegativeButton("Batal", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                    startActivityForResult(intent, REQUEST_IMPORT_FILE);
                } catch (RuntimeException error) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this,
                            "Tidak bisa membuka pemilih file.", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("file".equals(scheme) && uri.toString().startsWith("file:///android_asset/")) {
                    return false;
                }
                if ("https".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        Toast.makeText(MainActivity.this, "Tidak ada aplikasi untuk membuka tautan.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String cleanFilename(String name) {
        if (name == null || name.trim().isEmpty()) return "halaman-baru.html";
        String cleaned = name.replaceAll("[/\\\\:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) return "halaman-baru.html";
        return cleaned;
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String filename, String mimeType, String base64Data) {
            try {
                byte[] decoded = Base64.decode(base64Data, Base64.DEFAULT);
                if (decoded.length > MAX_EXPORT_BYTES) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "File terlalu besar untuk diekspor sekaligus.", Toast.LENGTH_LONG).show());
                    return;
                }
                pendingBytes = decoded;
                pendingMime = (mimeType == null || mimeType.trim().isEmpty())
                        ? "application/octet-stream" : mimeType;
                pendingName = cleanFilename(filename);
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingMime);
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQUEST_CREATE_FILE);
                    } catch (ActivityNotFoundException error) {
                        clearPendingSave();
                        Toast.makeText(MainActivity.this,
                                "Pemilih penyimpanan tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (IllegalArgumentException error) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Data file tidak valid.", Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface
        public String getProjectLibrary() {
            File file = new File(getFilesDir(), "html-maker-projects.json");
            if (!file.exists()) return "[]";
            try (FileInputStream input = new FileInputStream(file);
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    output.write(buffer, 0, count);
                    if (output.size() > MAX_PROJECT_LIBRARY_BYTES) return "[]";
                }
                return output.toString("UTF-8");
            } catch (Exception error) {
                return "[]";
            }
        }

        @JavascriptInterface
        public boolean saveProjectLibrary(String json) {
            if (json == null) return false;
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_PROJECT_LIBRARY_BYTES) return false;

            File destination = new File(getFilesDir(), "html-maker-projects.json");
            File temporary = new File(getFilesDir(), "html-maker-projects.json.tmp");
            File backup = new File(getFilesDir(), "html-maker-projects.json.bak");
            try {
                try (FileOutputStream output = new FileOutputStream(temporary, false)) {
                    output.write(bytes);
                    output.flush();
                    output.getFD().sync();
                }
                if (backup.exists()) backup.delete();
                if (destination.exists() && !destination.renameTo(backup)) {
                    temporary.delete();
                    return false;
                }
                if (!temporary.renameTo(destination)) {
                    if (backup.exists()) backup.renameTo(destination);
                    temporary.delete();
                    return false;
                }
                if (backup.exists()) backup.delete();
                return true;
            } catch (Exception error) {
                temporary.delete();
                if (backup.exists() && !destination.exists()) backup.renameTo(destination);
                return false;
            }
        }

        @JavascriptInterface
        public void setAppTheme(String themeName) {
            runOnUiThread(() -> {
                boolean dark = "dark".equals(themeName) || "midnight".equals(themeName);
                int barColor;
                if ("midnight".equals(themeName)) barColor = 0xFF101522;
                else if (dark) barColor = 0xFF111519;
                else if ("mint".equals(themeName)) barColor = 0xFFEAF4EF;
                else if ("lavender".equals(themeName)) barColor = 0xFFF2EFF9;
                else if ("cream".equals(themeName)) barColor = 0xFFF5F0E7;
                else barColor = 0xFFF5F6F8;
                getWindow().setStatusBarColor(barColor);
                getWindow().setNavigationBarColor(barColor);
                getWindow().getDecorView().setSystemUiVisibility(dark ? 0 :
                        View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                if (webView != null) webView.setBackgroundColor(barColor);
            });
        }

        @JavascriptInterface
        public String appVersion() {
            return "1.2.1";
        }
    }

    private void clearPendingSave() {
        pendingBytes = null;
        pendingMime = null;
        pendingName = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CREATE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBytes != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (output == null) throw new IllegalStateException("Output stream is null");
                    output.write(pendingBytes);
                    output.flush();
                    Toast.makeText(this, "File berhasil disimpan.", Toast.LENGTH_LONG).show();
                } catch (Exception error) {
                    Toast.makeText(this, "Gagal menyimpan file: " + error.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
            clearPendingSave();
        } else if (requestCode == REQUEST_IMPORT_FILE) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("if(window.HTMLMaker && HTMLMaker.isMenuOpen && HTMLMaker.isMenuOpen()){HTMLMaker.closeMenu();true}else if(window.HTMLMaker && HTMLMaker.isPreview()){HTMLMaker.togglePreview(false);true}else{false}", value -> {
                if (!"true".equals(value)) finish();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
