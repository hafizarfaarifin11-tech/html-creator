# HTML Maker v1.2.2

## Perbaikan CSS per elemen
- Menambahkan kolom Nama Class CSS pada pengaturan setiap elemen.
- Class CSS diterapkan ke elemen konten yang dipilih di kanvas, bukan ke seluruh halaman atau editor.
- Selector seperti `.melayang` langsung bekerja di pratinjau dan HTML hasil ekspor.
- Nama class divalidasi, mendukung beberapa class yang dipisahkan spasi, dan ikut tersimpan dalam proyek.
- Memperbarui versi aplikasi menjadi 1.2.2 (versionCode 6).
- Workflow GitHub Actions dan ikon aplikasi dipertahankan tanpa perubahan.
