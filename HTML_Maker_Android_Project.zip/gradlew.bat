@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "GRADLE_HOME=%USERPROFILE%\.gradle\html-maker\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  set "DIST_DIR=%USERPROFILE%\.gradle\html-maker"
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $v='%GRADLE_VERSION%'; $d='%DIST_DIR%'; $z=Join-Path $d ('gradle-'+$v+'-bin.zip'); Invoke-WebRequest ('https://services.gradle.org/distributions/gradle-'+$v+'-bin.zip') -OutFile $z; Expand-Archive -Force $z $d"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
endlocal
