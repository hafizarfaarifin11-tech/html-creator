# HTML Maker v1.2.3 — Perbaikan CSS independen per elemen

- Menambahkan kolom CSS khusus di setiap elemen, bukan lagi mengandalkan satu kolom CSS global untuk semua elemen.
- Setiap elemen menyimpan kode CSS sendiri di properti `customCss`; berpindah atau menghapus CSS elemen lain tidak mengubah kode tersebut.
- CSS per elemen diterapkan secara terisolasi di preview dan HTML ekspor menggunakan atribut target internal.
- Nama `@keyframes` otomatis dinamespace berdasarkan ID elemen, jadi dua teks dapat memakai nama animasi yang sama tanpa saling menimpa.
- CSS global halaman tetap tersedia secara terpisah di tab Desain.
- Proyek lama dimigrasikan dengan aman; CSS global lama tetap dipertahankan.
- Version Name 1.2.3, Version Code 7.
- Workflow GitHub Actions dan ikon aplikasi tidak diubah.
